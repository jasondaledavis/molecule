<?php

include_once ( 'class-tgm-plugin-activation.php' );

function wpi_register_required_plugins() {

    $plugins = array(

        array(
            'name'      => 'Advanced Ads',
            'slug'      => 'advanced-ads',
            'required'  => false,
        ),

        array(
            'name'      => 'Leadin',
            'slug'      => 'leadin',
            'required'  => false,
        ),

        array(
            'name'      => 'Hubspot for Gravity Forms',
            'slug'      => 'gravityforms-hubspot',
            'required'  => false,
        ),

        array(
            'name'      => 'HubSpot Tracking Code for WordPress',
            'slug'      => 'hubspot-tracking-code',
            'required'  => false,
        ),

    );

    tgmpa( $plugins );

}

add_action( 'tgmpa_register', 'wpi_register_required_plugins' );