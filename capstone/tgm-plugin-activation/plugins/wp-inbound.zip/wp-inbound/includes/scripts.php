<?php
// Add custom CSS styling to Visual Composer
if ( ! defined( 'WPB_VC_VERSION' ) ) {
        return;
    }
    if ( ! function_exists( 'wpi_visual_composer_CSS' ) ) {
        function wpi_visual_composer_CSS() {

            if ( is_admin() && ! ( isset( $_GET['vc_action'] ) && $_GET['vc_action'] == 'vc_inline' ) ) {
                wp_enqueue_style( 'wpi-vc-backend', plugin_dir_url( __FILE__ ) . 'css/backend.css' );
            }
        }

        add_action( 'vc_after_init_base', 'wpi_visual_composer_CSS' );
    }

if (!function_exists('wpi_styles')) {

    function wpi_styles() {
        
        wp_register_style( 'inbound-css', plugin_dir_url( __FILE__ ) . 'css/inbound.css' );
        wp_enqueue_style( 'inbound-css' );
    }
    add_action('init', 'wpi_styles');
}

if (!function_exists('wpi_queue_assets')) {

    function wpi_queue_assets() {      
        if ( !is_admin() ) {
        
        wp_enqueue_script( 'jquery' );
        
      // Register Scripts
        wp_register_script( 'v2-js', plugin_dir_url( __FILE__ ) . 'js/v2.js', 'jquery', '1.0' );
        wp_enqueue_script( 'v2-js' );

        wp_register_script( 'v2-legacy-js', plugin_dir_url( __FILE__ ) . 'js/v2-legacy.js', 'jquery', '1.0' );
        wp_enqueue_script( 'v2-legacy-js' );
        } 
    }
}

add_action( 'wp_enqueue_scripts', 'wpi_queue_assets' );