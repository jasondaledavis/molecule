<?php
/*-----------------------------------------------------------------------------------*/
/*  HS FORM 
/*-----------------------------------------------------------------------------------*/

if (!function_exists('hs_form')) {

    function hs_form($atts, $content = null) {

        $args = array(
            "form_id" => "",
            "el_class" => ""
        );

        extract(shortcode_atts($args, $atts));

    
        $hs_settings = get_option('hs_settings');
        
        $portalID = $hs_settings["hs_portal"];

        $html = "";


        $html .="<script type='text/javascript'>
              hbspt.forms.create({ 
                css: '',
                portalId: '$portalID',
                formId: '$form_id'
              });
            </script>";
        
        return $html;

    }

}

add_shortcode('hs_form', 'hs_form');

/* HS FORM METABOX */
if ( function_exists('vc_map') ) {
    vc_map( array(
            "name" => __( "HS Form" ),
            "base" => "hs_form",
            "category" => 'HS Elements',
            "icon" => "",
            "class" => "hs_form",
            "allowed_container_element" => 'vc_row',
            "description" => __( "Add your HubSpot Form ID" ),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => __( 'Form ID' ),
                    'param_name' => 'form_id',
                    'description' => __( 'Exmaple ID: cfb48bc9-4fe7-4c3a-b81d-b0b4ebd759ef.' ),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __( 'Extra class name' ),
                    'param_name' => 'el_class',
                    'description' => __( 'If you wish to style a particular content element differently, then use this field to add a class name and then refer to it in your css file.' ),
                ),
            )
    ) );
}