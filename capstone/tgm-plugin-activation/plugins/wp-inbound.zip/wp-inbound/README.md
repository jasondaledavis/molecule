# WP Inbound Plugin

###  Contributors: Jason Davis

- Requires at least: 4.0+
- Tested up to: 4.3
- License: GNU GENERAL PUBLIC LICENSE
- License URI: http://www.gnu.org/licenses/gpl-3.0.en.html

### A Plugin for the Elemental Theme to add inbound marketing plugins and tools to super-power the Elemental theme.

### Installation

Download from Capstone Creations Github Private Repo and upload via SFTP to /wp-content/plugins and activate through your WordPress Admin 

= or =

Install by clicking \"Add New\" in the Plugin WP Admin and selecting the .zip file.

### Frequently Asked Questions 

Q: Does this plugin work with any theme?

A: Nope. Just for Elemental by Capstone Creations.

== Changelog ==
*** WP Inbound Plugin Changelog ***

2016.03.17 - Version 1.0
	* First Release!