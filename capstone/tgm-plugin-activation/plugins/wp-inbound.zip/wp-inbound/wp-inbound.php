<?php
/*
* Plugin Name: WP Inbound
* Plugin URI: http://element502.com
* Description: Inbound Marketing Tools and extensions.
* Version: 1.0
* Author: Jason Davis
* Author URI: http://element502.com
* License: GNU General Public License
* License URI: https://www.gnu.org/licenses/gpl.html
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// Register CTA CPT
require_once( dirname(__FILE__) . '/cpt/types.php');

// Adds plugin JS and CSS
require_once( dirname(__FILE__) . '/includes/scripts.php' );

// Shortcode functions
require_once( dirname(__FILE__) . '/includes/shortcode-functions.php');

// TGM Plugin Activation
require_once( dirname(__FILE__) . '/includes/tgm-plugin-activation/init.php');