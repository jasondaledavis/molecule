<?php

// Register Custom Post Type for Landing Pages
function landing_pages() {

    $labels = array(
        'name'                  => _x( 'Landing Pages', 'Post Type General Name', 'wpi' ),
        'singular_name'         => _x( 'Landing Page', 'Post Type Singular Name', 'wpi' ),
        'menu_name'             => __( 'Landing Pages', 'wpi' ),
        'name_admin_bar'        => __( 'Landing Pages', 'wpi' ),
        'parent_item_colon'     => __( 'Parent Item:', 'wpi' ),
        'all_items'             => __( 'All Items', 'wpi' ),
        'add_new_item'          => __( 'Add New Item', 'wpi' ),
        'add_new'               => __( 'Add New', 'wpi' ),
        'new_item'              => __( 'New Item', 'wpi' ),
        'edit_item'             => __( 'Edit Item', 'wpi' ),
        'update_item'           => __( 'Update Item', 'wpi' ),
        'view_item'             => __( 'View Item', 'wpi' ),
        'search_items'          => __( 'Search Item', 'wpi' ),
        'not_found'             => __( 'Not found', 'wpi' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'wpi' ),
        'items_list'            => __( 'Items list', 'wpi' ),
        'items_list_navigation' => __( 'Items list navigation', 'wpi' ),
        'filter_items_list'     => __( 'Filter items list', 'wpi' ),
    );
    $args = array(
        'label'                 => __( 'Landing Page', 'wpi' ),
        'description'           => __( 'Landing Pages for Inbound Marketing', 'wpi' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields', 'page-attributes', ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-media-document',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => false,       
        'exclude_from_search'   => true,
        'publicly_queryable'    => true,
        'capability_type'       => 'page',
    );
    register_post_type( 'lander', $args );

}
add_action( 'init', 'landing_pages', 0 );

// Register Custom Post Type Thank You Page
function thank_you_pages() {

    $labels = array(
        'name'                  => _x( 'TY Pages', 'Post Type General Name', 'wpi' ),
        'singular_name'         => _x( 'TY Page', 'Post Type Singular Name', 'wpi' ),
        'menu_name'             => __( 'TY Pages', 'wpi' ),
        'name_admin_bar'        => __( 'TY Pages', 'wpi' ),
        'parent_item_colon'     => __( 'Parent Item:', 'wpi' ),
        'all_items'             => __( 'All Items', 'wpi' ),
        'add_new_item'          => __( 'Add New Item', 'wpi' ),
        'add_new'               => __( 'Add New', 'wpi' ),
        'new_item'              => __( 'New Item', 'wpi' ),
        'edit_item'             => __( 'Edit Item', 'wpi' ),
        'update_item'           => __( 'Update Item', 'wpi' ),
        'view_item'             => __( 'View Item', 'wpi' ),
        'search_items'          => __( 'Search Item', 'wpi' ),
        'not_found'             => __( 'Not found', 'wpi' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'wpi' ),
        'items_list'            => __( 'Items list', 'wpi' ),
        'items_list_navigation' => __( 'Items list navigation', 'wpi' ),
        'filter_items_list'     => __( 'Filter items list', 'wpi' ),
    );
    $args = array(
        'label'                 => __( 'TY Page', 'wpi' ),
        'description'           => __( 'TY Pages for Inbound Marketing', 'wpi' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields', 'page-attributes', ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-smiley',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => false,       
        'exclude_from_search'   => true,
        'publicly_queryable'    => true,
        'capability_type'       => 'page',
    );
    register_post_type( 'ty', $args );

}
add_action( 'init', 'thank_you_pages', 0 );